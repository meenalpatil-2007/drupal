CONTENTS OF THIS FILE
---------------------

 * Description
 * Installation


Description
------------

The Range module defines various numeric range field types for the Field module.
Ranges can be in integer, decimal, or floating-point form, and they can be
formatted when displayed. Range fields can be limited to a specific set of input
values or to a range of values.


INSTALLATION
------------

Install as usual, see http://drupal.org/node/70151 for further information.
